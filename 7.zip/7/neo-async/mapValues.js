'use stirct';

module.exports = require('./async').mapValues;
