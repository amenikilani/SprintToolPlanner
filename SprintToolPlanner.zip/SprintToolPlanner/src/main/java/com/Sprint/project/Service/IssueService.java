package com.Sprint.project.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.Sprint.project.controller.Generate;
import com.Sprint.project.model.Issue;
@Service
public class IssueService {
	
	    private static final ArrayList<Issue> issueMap = new ArrayList<Issue>();
	    static {
	        try {
				initIssues();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
	    private static void initIssues() throws IOException {
	        String line = null;
	        int i = 0;
	        String csvFile ="/home/ameni/Desktop/stage FIS/releaseppNew.csv";
	        BufferedReader bufferReader;
	        String[] mm = null ;
	        String BA_ETA;
	    	String Dev_ETA;
	        String Sprint;
	        String StoryPoints;
	    	String Priority;
	       //Ouvrir le fichier CSV 
	        bufferReader = new BufferedReader(new FileReader(csvFile));
     	    // transformer le contenu de fichier csv dans arrayList issueMap       
	        int numLigne =0 ;
	        while((line = bufferReader.readLine())!= null)
	        {         
	                  mm = line.split(",");   
	       	          BA_ETA = mm[0];
        	          Dev_ETA = mm[1];
	      	          Sprint = mm[2];
	      	          StoryPoints = mm[3];
	      	    	  Priority = mm[4];
	      	    	  Issue issue1 = new Issue( numLigne, BA_ETA, Dev_ETA, Sprint,  StoryPoints,  Priority );
	      	    	issueMap.add(numLigne , issue1) ;
	      	    	numLigne++;
                       i++;}
	       
	    }
	 
	    public Issue getIssue(String issueNo) {
	        return issueMap.get(Integer.parseInt(issueNo));
	    }
	  public Issue addIssue(Issue issue) throws IOException, ParseException {
	       /*String line = null;
	s        int i = 0;
	        BufferedReader bufferReader;
	        String[] mm = null ;
	        String csvFile ="/home/ameni/Desktop/stage FIS/releaseppNew.csv";
	        bufferReader = new BufferedReader(new FileReader(csvFile));
	        ArrayList<String[]> al = new ArrayList<String[]>();
	        while((line = bufferReader.readLine())!= null)
	        {
	              mm = line.split(",");
	              al.add(i,mm) ;
	              i++;
	        }
	    	issueMap.add(issue);
	    	System.out.println("add");
		    issue.setBA_ETA(Generate.ChangerBA(issue.getBA_ETA(), al.size(), al));
		    issue.setDev_ETA(Generate.ChangerDev(issue.getDev_ETA(), al.size(), al));*/
		  //  String newSprint = issue.getSprint();
		    //String newPriority = issue.getPriority();
		    //String newStoryPoints = issue.getStoryPoints();
	    	//issue.setBA_ETA(Generate.ChangerBA(newDate, NumLigne, al));
	    	issueMap.add(issue);
	        return issue;
	    }
	 
	    public Issue updateIssue(Issue  issue) {
	    	issueMap.remove(issue.getId());
	    	issueMap.add(issue.getId(), issue);
	        return issue;
	    }
	 
	    public void deleteIssue(int id) {
	        issueMap.remove(id);
	    }
	 
	    public List<Issue> getAllIssues() {
	        //Collection<Issue> c = issueMap.();String.valueOf(
	      //  List<Issue> list = new ArrayList<Issue>();
	        //list.add(id,issueMap. );;
	        return issueMap;
	    }
	 
	}