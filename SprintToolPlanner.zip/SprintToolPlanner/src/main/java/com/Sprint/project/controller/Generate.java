package com.Sprint.project.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//cette classe engloba toutes les fonctions que j'ai créée dans mon poke afin de manipuler le fichier csv que j'ai 
public class Generate {
	
	/*changer Ba_ETA
	 *cette fonction a pour but de changer le Ba_ETA en tenant 
	 *compte qu'elle doit etre avant le Dev_Eta et avant le début du Sprint 
	 *  */
	public static String ChangerBA(String newDate , int NumLigne,ArrayList<String[]>  al) throws IOException, ParseException {
		 SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); 
	    Date date1 = sdf.parse(newDate); 
	    String finall="";
		if (date1.before(RetourneDev_ETA(NumLigne)) || date1.before(RetourneDebSprint(NumLigne))){
	            al.get(NumLigne)[0] =  newDate;
	           finall="yesssssss";
		}else {
			    finall="BA should be before dev !!!";
		}
		return finall;   
	}
	
	/*changer Dev_ETA
	 *cette fonction a pour but de changer le Dev_ETA en tenant 
	 *compte qu'elle doit etre entre la date de début du Sprint ou la fin ou egale a une d'eux 
	 *  */
	public static String ChangerDev(String newDateD , int NumLigne , ArrayList<String[]> al ) throws ParseException, IOException {
		 SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); 
	    Date date1 = sdf.parse(newDateD);
	    String finalll="" ;
	    Date DateDeb ;
	    Date DateFin ;
	    if(date1.after(RetourneBA_ETA(NumLigne))) {
	    	 al.get(NumLigne)[1] = newDateD;
	         System.out.println("badalna ");
	     	 DateDeb = RetourneDebSprint(NumLigne) ; 
	   	     DateFin = RetourneFinSprint(NumLigne) ;
	         if((date1.before(DateFin) || date1.equals(DateFin))&& (date1.after(DateDeb) || date1.equals(DateDeb))) {
	   	      finalll="cvvvvvvvvvvvvvvvvvvvvvv " ;}
	     	 else {
	       	    finalll="il faut changer le sprint " ;
	       	    int p =1;
	       	    while (p<al.size()) {
	            	Date DateDebp = RetourneDebSprint(p) ; 
	           	    Date DateFinp = RetourneFinSprint(p) ;
	                if(date1.before(DateFinp) && date1.after(DateDebp)) {
	                	 al.get(NumLigne)[2] =  al.get(p)[2];
	                }
	                p++;
	       	    } }}
	    else {
	    	finalll="BA 9ball lezem" ;
	    }
		return finalll;
	}
	
	//retourner priority
	  public static String retournePriority (ArrayList<String[]> al , int NumLigne ) {
		  return al.get(NumLigne)[4];
	   }
	  //changer forme du mois
		public static String switchMonth(String month) {
	        String monthString="";
	        switch (month) {
	            case "01":
	                monthString="Jan" ; 
	                break;
	            case "02":
	                monthString="Feb" ;
	                break;
	            case "03":
	                monthString="Mar";
	                break;
	            case "04":
	                monthString="Apr" ;
	                break;
	            case "05":
	                monthString="May";
	                break;
	            case "06":
	                monthString="Jun";
	                break;
	            case "07":
	                monthString="Jul" ;
	                break;
	            case "08":
	                monthString="Aug";
	                break;
	            case "09": 
	                monthString="Sep";
	                break;
	            case "10": 
	                monthString="Oct";
	                break;
	            case "11": 
	                monthString="Nov";
	                break;
	            case "12": 
	                monthString="Dec";
	                break; 
	            default: monthString="Invalid month";
	                     break;
	        }
	        return monthString;
		}
	
		/*de format "dd-mm-yyyy" to date de sprint 
		 *  on convertit cette date pour devenir :
		 *  la format finale expl : "23May_05jun18"
		 */
		public static String ReglerForm(Date dateDebut , Date dateFine  ) throws ParseException {
			String formatSprintFin="";
			String formatSprintDeb="";
			String FormatFinal="";
			Format formatter = new SimpleDateFormat("dd-MM-yyyy");
			String s1 = formatter.format(dateDebut);
			String s2 = formatter.format(dateFine);

	        String d = s1.substring(0, 2);
	        String m = s1.substring(3, 5);
	        String y = s1.substring(8, 10); 
	        formatSprintFin=formatSprintFin.concat(d).concat(switchMonth(m)).concat(y);
	       
	        String d2 = s2.substring(0, 2);
	        String m2 = s2.substring(3, 5);
	        String y2 = s2.substring(8, 10);
	        formatSprintDeb=formatSprintDeb.concat(d2).concat(switchMonth(m2)).concat("_");
	        FormatFinal=FormatFinal.concat(formatSprintDeb).concat(formatSprintFin);

	        return FormatFinal; 
		}
		
		//RetourneBA_ETA
		public static Date RetourneBA_ETA(int NumLigne) throws IOException, ParseException {
			ArrayList<String[]>  al= retourneListe("/home/ameni/Desktop/stage FIS/releasepp.csv");
			String sousChaine1 ="";
			sousChaine1 = al.get(NumLigne)[0];
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dateBA = sdf.parse(sousChaine1);
			
				return dateBA;}
		// retourne la date de début de sprint 
	    public static Date RetourneDebSprint(int NumLigne) throws IOException, ParseException {
	        ArrayList<String[]>  al= retourneListe("/home/ameni/Desktop/stage FIS/releasepp.csv");
	        int pos=0;
	        int pos2=0;
	        for(int i1=0;i1<al.get(1)[2].length()-1;i1++) {
	            String sousChaine1 = al.get(NumLigne)[2].substring(i1, i1+1);
	            if(sousChaine1.equals("-")) {
	            	 pos = i1;            		 
	            }  
	            if(sousChaine1.equals("_")) {
			    	 pos2 = i1; }
	            }
	            String ssou =al.get(NumLigne)[2].substring(pos+2, pos2);
			    if ( ssou.length() == 4) {
		            ssou = "0".concat(ssou);}
		     
	            String d = ssou.substring(0, 2);
	            String m = ssou.substring(2, 5);
	          
	            String newDate = d.concat("-").concat(m).concat("-").concat("18");
	            SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
	            Date dateN = formatter.parse(newDate);     
	       	    return dateN ;
	    			}
	    
//Retourne le Dev_ETA
		public static Date RetourneDev_ETA(int NumLigne) throws IOException, ParseException {
			ArrayList<String[]>  al= retourneListe("/home/ameni/Desktop/stage FIS/releasepp.csv");
			String sousChaine1 ="";
			   // for(int i1=0;i1<al.get(NumLigne)[2].length();i1++) {
			    sousChaine1 = al.get(NumLigne)[1];
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); //Pour déclarer les valeurs dans les nouveaux objets Date, employez le même format de date que pour créer des dates
			    Date dateDev = sdf.parse(sousChaine1);
			     //   }
					return dateDev;}
		
//retourne date de début de sprint 
    	public static Date RetourneFinSprint(int NumLigne) throws IOException, ParseException {
    		ArrayList<String[]>  al= retourneListe("/home/ameni/Desktop/stage FIS/releasepp.csv");
    		int pos=0;
    		int pos2=0;
    		String d ="";
    		String m ="";
    		String y="";
    		for(int i1=0;i1<al.get(1)[2].length()-1;i1++) {
    		    String sousChaine1 = al.get(NumLigne)[2].substring(i1, i1+1);
    		    if(sousChaine1.equals("-")) {
    		    	 pos = i1; }
    		    if(sousChaine1.equals("_")) {
    		    	 pos2 = i1; }
    		    }
    		    String ssou = al.get(NumLigne)[2].substring(pos2+1);    
    	        if ( ssou.length() == 7) {
    		             ssou = "0".concat(ssou);}
    		       d = ssou.substring(0, 2);
    		       m = ssou.substring(2, 5);
       		       y = ssou.substring(5, 7); 	  
    	    String newDate = d.concat("-").concat(m).concat("-").concat(y);
    		    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
    		    Date dateN = formatter.parse(newDate);     
    		    return dateN ;
    		        
    				}
   //retourne une liste de String .. chaque string est une ligne de fichier csv 
  	  public static ArrayList<String[]> retourneListe (String csvFile) throws IOException{
	        String line = null;
	        int i = 0;
	        BufferedReader bufferReader;
	        String[] mm = null ;
	        //Ouvrir le fichier CSV 
	        bufferReader = new BufferedReader(new FileReader(csvFile));
	        // transformer le contenu de fichier csv dans arrayList al        
	        ArrayList<String[]> al = new ArrayList<String[]>();
	        while((line = bufferReader.readLine())!= null)
	        {
	              mm = line.split(",");
	              al.add(i,mm) ;
	              i++;
	        }
	        return al;	
	}
/* retourner le num de sprint .
 * par exemple pour le sprint "TUN WEEK 1 - 03Jan_16Jan18" 
 * le num de sprint = 1 (c'est le num juste aprés le WEEK" 
	*/
	   public static String RetourneNumSprint(int NumLigne) throws IOException {
		    ArrayList<String[]>  al= retourneListe("/home/ameni/Desktop/stage FIS/releasepp.csv");
		    String sousChaine1 ="";
		    String sousChaine ="";
		    int NumS =0;
		    int pos = 0 ;
			for(int i1=0;i1<al.get(1)[2].length()-1;i1++) {
			    sousChaine1 = al.get(NumLigne)[2].substring(i1, i1+1);
			    if(sousChaine1.equals("-")) {
			    	 pos = i1; }}
			sousChaine = al.get(NumLigne)[2].substring(10, pos-1);

		      if(sousChaine.length()==2) {
		    	  return sousChaine;
		      }else {
		    	   return   sousChaine.substring(0, 1) ;
		      }
		      }
	   
	   // calculer la somme des story points d'un sprint donné :
	   public static float StoryPointSum(ArrayList<String[]> al  , int numSprint) throws NumberFormatException, IOException {
	          float sum = 0;
			  for (int j=1 ;j<=al.size()-1 ;j++) {
				  if (Integer.parseInt(RetourneNumSprint(j)) == numSprint) {
				  sum = sum + Float.parseFloat(al.get(j)[3]);
				  }
				  	  }		
			  return sum;
	      }


}
