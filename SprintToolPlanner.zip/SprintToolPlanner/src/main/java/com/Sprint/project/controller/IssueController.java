package com.Sprint.project.controller;

//import java.awt.PageAttributes.MediaType;
import org.springframework.http.MediaType;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.Sprint.project.Service.IssueService;
import com.Sprint.project.model.Issue;

@CrossOrigin(origins = "*")
@RestController
public class IssueController {

	    @Autowired
	    private IssueService issueService;
	 
	    @RequestMapping("/")
	    @ResponseBody
	    public String welcome() {
	        return "Welcome to Sprint Planner Tool";
	    }
	    @RequestMapping(value = "/issues", //
	            method = RequestMethod.GET, //
	            produces = { MediaType.APPLICATION_JSON_VALUE, //
	                    MediaType.APPLICATION_XML_VALUE })
	    @ResponseBody
	    public List<Issue> getIssues() {
	        List<Issue> list = issueService.getAllIssues();
	        return list;
	    }
	    @RequestMapping(value = "/issues/{id}", //
	            method = RequestMethod.GET, //
	            produces = { MediaType.APPLICATION_JSON_VALUE, //
	                    MediaType.APPLICATION_XML_VALUE })
	    @ResponseBody
	    public Issue getIssue(@PathVariable("id") int id) {
	        return issueService.getIssue(String.valueOf(id));
	    }
	    // URL:
	    // http://localhost:8053/issues
	    @RequestMapping(value = "/issues", //
	            method = RequestMethod.POST, //
	            produces = { MediaType.APPLICATION_JSON_VALUE, //
	                    MediaType.APPLICATION_XML_VALUE })
	    
	    public Issue addIssue(@RequestBody Issue issue) throws IOException, ParseException {
	 
	        System.out.println("(Service Side) Creating issue: " + String.valueOf(issue.getId()));
	        return issueService.addIssue(issue);
	    }
	    // URL:
	    // http://localhost:8053/issues/{id}	 
	    @RequestMapping(value = "/issues/{id}", //
	            method = RequestMethod.PUT, //
	            produces = { MediaType.APPLICATION_JSON_VALUE, //
	                    MediaType.APPLICATION_XML_VALUE })
	    public Issue updateIssue(@RequestBody Issue issue) {
	 
	        System.out.println("(Service Side) Editing issue: " + String.valueOf(issue.getId()));
	 
	        return issueService.updateIssue(issue);
	    }
	 
	    // URL:
	    // http://localhost:8053/issues/{id}
		@RequestMapping(value = "/issues/{id}", //
	            method = RequestMethod.DELETE, //
	            produces = { MediaType.APPLICATION_JSON_VALUE, //
	            		MediaType.APPLICATION_XML_VALUE })
	            
	    
	  public void deleteIssue(@PathVariable("id") int id) {
	 
	        System.out.println("(Service Side) Deleting issue: " + String.valueOf(id));
	 
	       issueService.deleteIssue(id);
	    }
	 
	}
