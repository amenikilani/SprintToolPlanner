package com.Sprint.project.model;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@EntityScan
public class Issue {
	private int id;

	private String BA_ETA;
	private String Dev_ETA;
	private String Sprint;
	private String StoryPoints;
	private String Priority;

	public Issue(int id,  String BA_ETA, String Dev_ETA, String Sprint,String StoryPoints,  String Priority){
	super();
	this.id = id;
	this.BA_ETA = BA_ETA;
	this.Dev_ETA = Dev_ETA;
	this.Sprint = Sprint;
	this.Priority= Priority ;
    this.StoryPoints = StoryPoints;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBA_ETA() {
		return BA_ETA;
	}
	public void setBA_ETA(String BA_ETA) {
		BA_ETA = BA_ETA;
	}
	public String getDev_ETA() {
		return Dev_ETA;
	}
	public void setDev_ETA(String Dev_ETA) {
		Dev_ETA = Dev_ETA;
	}
	public String getSprint() {
		return Sprint;
	}
	public void setSprint(String Sprint) {
		Sprint = Sprint;
	}
	public String getStoryPoints() {
		return StoryPoints;
	}
	public void setStoryPoints(String StoryPoints) {
		StoryPoints = StoryPoints;
	}
	public String getPriority() {
		return Priority;
	}
	public void setPriority(String Priority) {
		Priority =Priority;
	}
	@Override
	public String toString() {
		return "Issue [id=" + id + ", BA_ETA=" + BA_ETA + ", Dev_ETA=" + Dev_ETA + ", Sprint=" + Sprint
				+ ", StoryPoints=" + StoryPoints + ", Priority=" + Priority + "]";
	}

}