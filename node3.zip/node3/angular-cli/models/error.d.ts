/// <reference types="node" />
export declare class NgToolkitError extends Error {
    constructor(message?: string);
}
