"use strict";
var ast_tools_1 = require('@angular-cli/ast-tools');
exports.NoopChange = ast_tools_1.NoopChange;
exports.MultiChange = ast_tools_1.MultiChange;
exports.InsertChange = ast_tools_1.InsertChange;
exports.RemoveChange = ast_tools_1.RemoveChange;
exports.ReplaceChange = ast_tools_1.ReplaceChange;
//# sourceMappingURL=/Users/hans/Sources/angular-cli/packages/angular-cli/utilities/change.js.map