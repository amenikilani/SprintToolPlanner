import { SprintPlannerFrontendPage } from './app.po';

describe('sprint-planner-frontend App', function() {
  let page: SprintPlannerFrontendPage;

  beforeEach(() => {
    page = new SprintPlannerFrontendPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
