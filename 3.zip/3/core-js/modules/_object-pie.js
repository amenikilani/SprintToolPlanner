exports.f = {}.propertyIsEnumerable;
