require('../modules/es7.string.trim-left');
require('../modules/es7.string.trim-right');
require('../modules/es7.symbol.async-iterator');
module.exports = require('./3');
