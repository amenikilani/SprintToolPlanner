import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Issue } from './issue';

@Injectable()
export class IssueService {
      //URL for CRUD operations
   issueUrl = "http://localhost:8053/issues";
    //Create constructor to get Http instance
    constructor(private http:Http) { 
    }
    //Fetch all articles
      getAllIssues(): Observable<Issue[]> {
          return this.http.get(this.issueUrl)
             .map(this.extractData)
              .catch(this.handleError);
  
      }
    //Create article
      createIssue(issue: Issue):Observable<any> {
        let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
          let options = new RequestOptions({ headers: cpHeaders });
          return this.http.post(this.issueUrl, issue, options)
                 .map(success => success.status)
                 .catch(this.handleError);
      }
    //Fetch article by id
      getIssueById(issueId: String): Observable<Issue> {
      let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: cpHeaders });
      console.log(this.issueUrl +"/"+ issueId);
      return this.http.get(this.issueUrl +"/"+ issueId)
           .map(this.extractData)
           .catch(this.handleError);
      }	
    //Update article
      updateIssue(issue: Issue):Observable<any> {
        let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
          let options = new RequestOptions({ headers: cpHeaders });
          return this.http.put(this.issueUrl +"/"+ issue.id, issue, options)
                 .map(success => success.status)
                 .catch(this.handleError);
                

      }
      //Delete article	
      deleteIssueById(issueId: String): Observable<number> {
      let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: cpHeaders });
      return this.http.delete(this.issueUrl +"/"+ issueId)
           .map(success => success.status)
           .catch(this.handleError);
      }	
    private extractData(res: Response) {
        let body = res.json();
          return body;
      }
      private handleError (error: Response | any) {
      console.error(error.message || error);
      return Observable.throw(error.status);
      }
  }