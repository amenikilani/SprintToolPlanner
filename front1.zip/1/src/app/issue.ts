export class Issue{
    id : number ;
	ba_ETA :String ;
	dev_ETA: String ;
	sprint: String ;
    storyPoints:String ;
    priority:String ;
	
    constructor(id : number ,ba_ETA :String ,dev_ETA: String ,sprint: String , storyPoints:String ,priority:String ){
        this.id = id;
        this.ba_ETA = ba_ETA;
        this.dev_ETA = dev_ETA;
        this.sprint= sprint;
        this.priority= priority ;
        this.storyPoints =storyPoints ;

    }
    }