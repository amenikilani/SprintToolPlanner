import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { IssueService } from '../issue.service';
import { Issue } from '../issue';

@Component({
   selector: 'app-issue',
   templateUrl: './issue.component.html',
   styleUrls: ['./issue.component.css']
})
export class IssueComponent implements OnInit { 
   //Component properties
   allIssues: Issue[];
   statusCode: number;
   requestProcessing = false;
   issueIdToUpdate = null;
   processValidation = false;
   files : FileList; 
 
   //Create form
   issueForm = new FormGroup({
       BA_ETA: new FormControl('', Validators.required),
	   Dev_ETA: new FormControl('', Validators.required),	
	   Sprint: new FormControl('', Validators.required),	   
       Priority: new FormControl('', Validators.required),	   
       StoryPoints: new FormControl('', Validators.required)	   
   });
   //Create constructor to get service instance
   constructor(private issueService: IssueService) {
   }
   //Create ngOnInit() and and load articles
   ngOnInit(): void {
	   this.getAllIssues();
   }   
   getFiles(event){ 
	this.files = event.target.files; 
} 
logForm(event) { 
	 console.log(this.files); 
} 
   //Fetch all articles
   getAllIssues() {
        this.issueService.getAllIssues()
		  .subscribe(
                data => this.allIssues = data,
                errorCode =>  this.statusCode = errorCode);   
   }
   //Handle create and update article
   onIssueFormSubmit() {
	  this.processValidation = true;   
	  if (this.issueForm.invalid) {
	       return; //Validation failed, exit from method.
	  }   
	  //Form is valid, now perform create or update
	  this.preProcessConfigurations();
	  let issue= this.issueForm.value;
	  if (this.issueIdToUpdate === null) {  
	    //Generate article id then create article
        this.issueService.getAllIssues()
	     .subscribe(issues => {
			 
		   //Generate article id	 
		   let maxIndex = issues.length - 1;
		   let issueWithMaxIndex = issues[maxIndex];
		   let issueId = issueWithMaxIndex.id + 1;
		   /*let ba_ETA = this.issueForm.value.ba_ETA;
		   let dev_ETA = this.issueForm.value.dev_ETA;
		   let sprint = this.issueForm.value.sprint;
		   let priority = this.issueForm.value.priority;
		   let storyPoints = this.issueForm.value.storyPoints;*/
		   issue.id = issueId;
		 /*  issue.ba_ETA= ba_ETA;
		   issue.dev_ETA = dev_ETA;
		   issue.sprint = sprint;
		   issue.priority = priority;
		   issue.storyPoints = storyPoints;*/
		   //Create article
     	   this.issueService.createIssue(issue)
			  .subscribe(successCode => {
					this.statusCode = successCode;
					this.getAllIssues();	
					this.backToCreateIssue();
				 },
				 errorCode => this.statusCode = errorCode
			   );
		 });		
	  } else {  
   	    //Handle update article
        issue.id = this.issueIdToUpdate; 		
	    this.issueService.updateIssue(issue)
	      .subscribe(successCode => {
		            this.statusCode = successCode;
				    this.getAllIssues();	
					this.backToCreateIssue();
			    },
		        errorCode => this.statusCode = errorCode);	  
	  }
   }
   //Load article by id to edit
   loadIssueToEdit(issueId: String) {
      this.preProcessConfigurations();
      this.issueService.getIssueById(issueId)
	      .subscribe(issue => {
		            this.issueIdToUpdate = issue.id;   
		            this.issueForm.setValue({ BA_ETA: issue.ba_ETA, Dev_ETA: issue.dev_ETA, Sprint : issue.sprint, Priority : issue.priority, StoryPoints : issue.storyPoints });
					this.processValidation = true;
					this.requestProcessing = false;   
		        },
		        errorCode =>  this.statusCode = errorCode);   
   }
   //Delete article
   deleteIssue(issueId: String) {
      this.preProcessConfigurations();
      this.issueService.deleteIssueById(issueId)
	      .subscribe(successCode => {
		            //this.statusCode = successCode;
					//Expecting success code 204 from server
					this.statusCode = 204;
				    this.getAllIssues();	
				    this.backToCreateIssue();
			    },
		        errorCode => this.statusCode = errorCode);    
   }
   //Perform preliminary processing configurations
   preProcessConfigurations() {
      this.statusCode = null;
	  this.requestProcessing = true;   
   }
   //Go back from update to create
   backToCreateIssue() {
      this.issueIdToUpdate = null;
      this.issueForm.reset();	  
	  this.processValidation = false;
   }
}
    
