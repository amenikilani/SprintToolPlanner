module.exports = {
	output: {
		library: "SockJS",
		libraryTarget: "umd"
	}
}
