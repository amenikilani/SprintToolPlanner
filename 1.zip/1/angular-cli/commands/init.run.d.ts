export default function initRun(commandOptions: any, rawArgs: string[]): any;
