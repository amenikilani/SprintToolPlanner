declare const CompletionCommand: any;
export default CompletionCommand;
