declare var _default: any;
export default _default;
