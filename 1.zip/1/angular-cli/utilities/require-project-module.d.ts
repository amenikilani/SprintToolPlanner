export declare function requireDependency(root: string, moduleName: string): any;
