module.exports = require('./readable').Duplex
