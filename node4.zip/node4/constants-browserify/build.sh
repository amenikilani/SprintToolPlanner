node -pe 'JSON.stringify(require("constants"), null, "  ")' > constants.json
