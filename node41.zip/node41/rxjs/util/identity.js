"use strict";
function identity(x) {
    return x;
}
exports.identity = identity;
//# sourceMappingURL=identity.js.map