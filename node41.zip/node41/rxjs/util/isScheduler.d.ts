import { Scheduler } from '../Scheduler';
export declare function isScheduler(value: any): value is Scheduler;
