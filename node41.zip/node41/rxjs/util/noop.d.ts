export declare function noop(): void;
