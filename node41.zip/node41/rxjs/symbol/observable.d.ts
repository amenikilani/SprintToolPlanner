export declare function getSymbolObservable(context: any): any;
export declare const observable: any;
/**
 * @deprecated use observable instead
 */
export declare const $$observable: any;
