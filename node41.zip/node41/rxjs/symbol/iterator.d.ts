export declare function symbolIteratorPonyfill(root: any): any;
export declare const iterator: any;
/**
 * @deprecated use iterator instead
 */
export declare const $$iterator: any;
