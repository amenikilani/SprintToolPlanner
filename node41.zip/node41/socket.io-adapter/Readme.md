
# socket.io-adapter

Default socket.io in-memory adapter class.

## How to use

This module is not intended for end-user usage, but can be used as an
interface to inheirt from from other adapters you might want to build.

As an example of an adapter that builds on top of this, please take a look
at [socket.io-redis](https://github.com/learnboost/socket.io-redis).

## License

MIT
