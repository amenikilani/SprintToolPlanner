declare module "ts-helpers" {
  // The "ts-helpers" module has no imports or exports, but can be used by modules to load the polyfill.
}
