# Installation
> `npm install --save @types/selenium-webdriver`

# Summary
This package contains type definitions for Selenium WebDriverJS (https://github.com/SeleniumHQ/selenium/tree/master/javascript/node/selenium-webdriver).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/selenium-webdriver

Additional Details
 * Last updated: Mon, 19 Dec 2016 21:54:11 GMT
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: none

# Credits
These definitions were written by Bill Armstrong <https://github.com/BillArmstrong>, Yuki Kokubun <https://github.com/Kuniwak>, Craig Nishina <https://github.com/cnishina>.
