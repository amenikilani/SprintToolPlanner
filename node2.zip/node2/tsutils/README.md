# Utility functions for working with typescript's AST

## Roadmap

* v1.x
  * Add tests - currently this package is implicitly tested through the dependent packages `tslint` and `tslint-consistent-codestyle`
  * Add contributing guidelines