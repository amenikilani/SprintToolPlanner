export declare function updateNotifierCheck(): void;
