'use strict';
module.exports = require('./spinners.json');
